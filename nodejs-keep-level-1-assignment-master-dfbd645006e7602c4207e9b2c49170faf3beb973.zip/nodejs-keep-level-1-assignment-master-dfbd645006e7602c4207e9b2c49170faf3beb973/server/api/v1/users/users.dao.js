let userModel = require('./users.entity');
let bcrypt = require('bcryptjs');
const uuidv1 = require('uuid/v1');
const loginUser = (userInfo) => {
  return new Promise((resolve, reject) => {
    try {      
      userModel.findOne({ userName: userInfo.username }, function(error, user){
        if(error) {
          reject({ message: 'Failed to find user due to unexpected error', status: 500 });
        }
        if(!user) {
          reject({ message: 'You are not registered user', status: 403 });
        }      
      
        bcrypt.compare(userInfo.password, user.password, function(error, result){
          if(error) {
            reject({ message: 'Failed to find user due to unexpected error', status: 500 });
          }
          if(!result) {
            reject({ message: 'Password is incorrect', status: 403 });
          }           
          resolve({ message: 'Successfully logged in', status: 200, userInfo: { userName: user.userName, userId: user.userId } });
        });
      });
      
    } catch (error) {
      reject({ message: 'Failed to login due to unexpected error', status: 500 });
    }
  }); 
}

const registerUser = (userInfo) =>{
  return new Promise((resolve, reject) => {
    try {
      
      userModel.findOne({ userName: userInfo.username }, function(error, user){
        if(error) {
          reject({ message: 'Failed to register due to unexpected error', status: 500 });
        }
        if(user) {
          reject({ message: 'username is already exist', status: 403 });
        }
      });

      let newUser = new userModel();
      newUser.userId = uuidv1();
      newUser.userName = userInfo.username;
      newUser.password = userInfo.password;

      newUser.save(function(error, addedUser) {
        if(error) {
          reject({ message: 'Failed to register due to unexpected error', status: 500 });
        } else {
          resolve({message: 'Successfully registered', status: 201, userInfo: { userName: addedUser.userName, userId: addedUser.userId }});
        }
      });    
    }catch(error) {
      reject({ message: 'Failed to register due to unexpected error', status: 500 });
    }
  });
}
 module.exports = {
  loginUser,
  registerUser
 }
