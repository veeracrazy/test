const usersDAO =  require('./users.dao');

// Handler to login user
const loginUser = (user) => {
  return usersDAO.loginUser(user);
}

// Handler to register user
const registerUser = (userDetails) => {
  return usersDAO.registerUser(userDetails);
}


module.exports = {
  loginUser,
  registerUser
}
