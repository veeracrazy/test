// module.exports = () =>{
//   console.log('inside users');
// }
module.exports = require('./users.router');
