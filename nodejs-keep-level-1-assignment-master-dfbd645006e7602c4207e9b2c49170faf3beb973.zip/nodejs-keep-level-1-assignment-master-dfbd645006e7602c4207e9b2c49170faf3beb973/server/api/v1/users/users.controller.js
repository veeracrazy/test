const usersService =  require('./users.service')

// Handler to login user
const loginUser = (user) => {
  return usersService.loginUser(user);
}

// Handler to register user
const registerUser = (userDetails) => {
  return usersService.registerUser(userDetails);
}


module.exports = {
  loginUser,
  registerUser
}
