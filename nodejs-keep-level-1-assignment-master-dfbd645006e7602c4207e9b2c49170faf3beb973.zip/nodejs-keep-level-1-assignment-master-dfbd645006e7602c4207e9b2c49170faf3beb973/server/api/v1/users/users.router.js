const router = require('express').Router();
const usersCtrl = require('./users.controller');

// api to login into the system
router.post('/login', (req, res, next) => {
  try {    
    usersCtrl.loginUser(req.body).then((response) => {
      res.status(response.status).send(response);
    },
    (err) => {    
      res.status(err.status).send(err);
    });  
  } catch (err) {    
    res.send({message: 'Failed to complete request'})
  }
});

// api to register a user into the system
router.post('/register', (req, res, next) => {
  try {    
    usersCtrl.registerUser(req.body).then((response) => {
      res.status(response.status).send(response);
    },
    (err) => {
      res.status(err.status).send(err);
    });
  } catch (err) {    
    res.send({message: 'Failed to complete request'})
  }
});

module.exports = router;
