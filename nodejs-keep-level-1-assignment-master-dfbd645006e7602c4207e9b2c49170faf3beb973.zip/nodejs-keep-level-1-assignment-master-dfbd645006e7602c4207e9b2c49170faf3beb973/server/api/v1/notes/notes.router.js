const router = require('express').Router();
const notesCtrl = require('./notes.controller');

// api to add a note
router.post('/', (req, res, next) => {
  let note = req.body;  
  let userId = req.query.userId;    
  try {    
    notesCtrl.addNote(userId, note).then((response) => {
      res.status(response.status).send(response.note);
    },
    (err) => {
      res.status(err.status).send(err);
    }
    );
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});

// api to get all notes into database
router.get('/', (req, res, next) => {
  let userId = req.query.userId; 
  try {
    notesCtrl.getNotes(userId).then((response) => {
      res.status(response.status).send(response.notes);
    },
    (err) => {
      res.status(err.status).send(err);
    }
    );
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});
// api to update a note
router.put('/:noteId', (req, res, next) => {
  try {
    let noteId = req.params.noteId;
    let editedNote =  req.body;
    notesCtrl.updateNote(noteId, editedNote).then((response) => {
      res.status(response.status).send(response.updatedNote);
    },
    (err) => {    
      res.status(err.status).send(err);
    }
    );
  } catch (err) {    
    res.send({message: 'Failed to complete request'})
  }
});

module.exports = router;
