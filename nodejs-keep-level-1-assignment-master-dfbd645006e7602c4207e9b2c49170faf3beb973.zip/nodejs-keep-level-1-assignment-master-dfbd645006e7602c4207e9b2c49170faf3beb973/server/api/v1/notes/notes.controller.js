const notesService =  require('./notes.service')

// Handler to add a note into a database
const addNote = (userId, note) => {
  return notesService.addNote(userId, note);
}

// Handler to get notes
const getNotes = (userId) => {
  return notesService.getNotes(userId);
}

// Handler to update note
const updateNote = (noteId, editedNote) => {
  return notesService.updateNote(noteId, editedNote);
}

module.exports = {
  addNote,
  getNotes,
  updateNote
}
