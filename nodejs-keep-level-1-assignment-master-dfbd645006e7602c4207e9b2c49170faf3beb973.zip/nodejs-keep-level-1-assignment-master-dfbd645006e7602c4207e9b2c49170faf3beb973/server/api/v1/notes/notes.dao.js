let noteModel = require('./notes.entity');
const uuidv1 = require('uuid/v1');

// handels to insert newly created note into the database
const addNote = (userId, note) => {  
  return new Promise((resolve, reject) => {
    try{
      let newNote = new noteModel();
      newNote.id = uuidv1();
      newNote.title = note.title;
      newNote.text = note.text;
      newNote.userId = userId;
      newNote.save((err, note) => {      
        if(err) {        
          reject({message: 'Internal Server Error', status: 500});
        } else {
          resolve({note: note, message: 'Note is added successfully', status:201});
        }
      });
    } catch(err){
      reject({message: 'Internal Server Error', status: 500});
    }
});
};
// handels to get all notes from database
const getNotes = (userId) => {
  return new Promise((resolve, reject) => {
    try{      
      noteModel.find({ userId: userId }, function(err, notes){
        if (err) {
          reject({message: 'Internal Server Error', status: 500});
        } else {
          resolve({notes: notes, status:200});
        }
      });
    } catch(err){      
      reject({message: 'Internal Server Error', status: 500});
    }
  });
};
// handels to update a note into the database
const updateNote = (noteId, editedNote) => {
  return new Promise((resolve, reject) => {
    try{
      delete editedNote['_id'];
      delete editedNote['userId'];
      delete editedNote['createdOn'];
      delete editedNote['id'];
      editedNote['modifiedOn'] = new Date();
      noteModel.findOneAndUpdate({id: noteId}, editedNote, {new: true}, function(err, note) {
        if (err) {      
          reject({message: 'Internal Server Error', status: 500});
        } else {
          resolve({updatedNote: note, message: 'Note is updated successfully', status: 200});
        }
      });
    } catch(err){
      reject({message: 'Internal Server Error', status: 500});
    }
  });
};

module.exports = {
  addNote,
  getNotes,
  updateNote
}
