// write your db connection code here
let mongoose = require('mongoose');
const { dbConfig }  = require('../config').appConfig;


// create mongo connection
function createMongoConnection() {
  mongoose.connect(dbConfig.mongoUrl, {useNewUrlParser: true});
}

// get mongo connection object
function getMongoConnection() {
  return mongoose.connection;
}

module.exports = {
  createMongoConnection,
  getMongoConnection
}
