const initializeMongooseConnection = require('./db').createMongoConnection;

const noteModel = require('./api/v1/notes/notes.entity');

const userModel = require('./api/v1/users/users.entity');

module.exports = {
	initializeMongooseConnection,
	noteModel,
	userModel
}