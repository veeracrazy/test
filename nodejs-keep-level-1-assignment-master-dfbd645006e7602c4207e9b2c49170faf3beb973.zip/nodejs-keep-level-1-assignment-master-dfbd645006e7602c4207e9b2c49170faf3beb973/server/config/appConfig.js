// Server configuration
const serverConfig = {
    port: 3000,
    hostname: '127.0.0.1'
}

const dbConfig = {
    mongoUrl: 'mongodb://127.0.0.1:27017/keep1'
}

module.exports = {
    serverConfig,
    dbConfig
}
