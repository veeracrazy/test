/* Replace undefined with Require of your Mongoose connection initialization method */
const initializeMongooseConnection = require('./db').createMongoConnection;
/* Replace undefined with Require of your note entity*/
const noteModel = require('./api/v1/notes/notes.entity');
/* Replace undefined with Require of your user entity*/
const userModel = require('./api/v1/users/users.entity');
/* Replace undefined with the method or function reference, which signs the token with given payload, expiry time and secret, call back should have error or signed token */
const signJWTToken = require('./api/v1/auth').createToken;
/* Replace undefined with the method or function reference, which verifies a given JWT Token and callback with error & payload */
const verifyJWTToken = require('./api/v1/auth').verifyToken;

module.exports = {
	initializeMongooseConnection,
	noteModel,
	userModel,
	signJWTToken,
	verifyJWTToken
}