let express = require('express');
let app = express();
let appService =  require('./app.service');

//write your logic here
appService.connectToDatabase();
appService.setAppMiddleware(app);
appService.apiSetUp(app);

module.exports = app;