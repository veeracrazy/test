let notesDAO = require('./notes.dao');

// handels to insert newly created note into the database
const addNote = (userId, note) => {
  return notesDAO.addNote(userId, note);
};
// handels to get all notes from database
const getNotes = (userId) => {
  return notesDAO.getNotes(userId);
};
// handels to update a note into the database
const updateNote = (noteId, editedNote) => {
  return notesDAO.updateNote(noteId, editedNote);
};

module.exports = {
  addNote,
  getNotes,
  updateNote
}
