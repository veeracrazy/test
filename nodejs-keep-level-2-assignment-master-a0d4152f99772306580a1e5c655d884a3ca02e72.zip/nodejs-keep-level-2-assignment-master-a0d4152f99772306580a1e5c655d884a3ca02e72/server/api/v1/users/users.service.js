const usersDAO =  require('./users.dao');
const { authConfig } = require('../../../config/appConfig');
const auth = require('../auth');

// Handler to login user
const loginUser = (user) => {  
  return new Promise((resolve, reject) => {
    usersDAO.loginUser(user)
    .then(result => {
      //console.log(result);
      auth.createToken(result.userInfo, authConfig.secret, '1hr', (err, token) => {
        if(err) reject({ message: 'Failed to generate token', status: 500 });
        resolve({ token: token, user: result.userInfo, status: 200 });
      })
    })
    .catch(err => reject(err));
  });
}

// Handler to register user
const registerUser = (userDetails) => {
  return usersDAO.registerUser(userDetails);
}


module.exports = {
  loginUser,
  registerUser
}
