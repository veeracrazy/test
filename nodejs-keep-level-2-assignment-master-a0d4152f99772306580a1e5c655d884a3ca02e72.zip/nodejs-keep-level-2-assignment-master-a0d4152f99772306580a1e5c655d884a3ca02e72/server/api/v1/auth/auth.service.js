const jwt = require('jsonwebtoken');

// Create token
const createToken = (payload, secret, expiryTime, done) => {
    jwt.sign(payload, secret, {
        expiresIn: expiryTime
    }, done);
};

// Verify token
const verifyToken = (token, secret, done) => {
    jwt.verify(token, secret, done);
};

module.exports = {
    createToken,
    verifyToken    
}