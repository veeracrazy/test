const authService =  require('./auth.service')
const { authConfig } = require('../../../config/appConfig');

// chek authenticated user or not
const checkAuthenticatedUser = (req, res, next) => {
    const authHeader = req.get('Authorization');    
    if (!authHeader) {
        res.status(403).send('Not Authorized');
    } else {
        const token = authHeader.replace('Bearer ', ''); 
        authService.verifyToken(token, authConfig.secret, (err, decoded) => {
            if (err) {
                res.status(403).send('Invalid Token');
            } else {
                req.userId = decoded.userId;
                next();
            }
        });
    }
};

module.exports = {
    checkAuthenticatedUser
}