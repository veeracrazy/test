const should = require('chai').should();
const request = require('supertest');
const app = require('../app');
const config = require('./test.config');
const modules = require('../modules');

// remove all users
before((done) => {
  modules.userModel.remove({}, (err) => {
    if(err) return done(err);
    done();
  });
});

//  testsuite
describe('Testing to register a user', function()
{
  //  testcase
  it('Should handle a request to register a user', function(done)
  {
    // Response body should have a key as userInfo which will hold 'username' value
    // status code = 201
    // response body will hold user.userName
    const testUser = config.validUser.user1;
    request(app)
      .post('/api/v1/users/register')
      .send(testUser)
      .expect(201)
      .end((error, response) => {
        if(error) return done(error);
        const username = response.body.userInfo.userName;
        username.should.equal(testUser.username, 'response should return proper userInfo');
      });
    done();
  });

  //  testcase
  it('Should handle a request to register a user multiple times with same username', function(done)
  {
    //Response body should have a key as message which will hold value as 'username is already exist'
    // status code = 403
    // response body will hold an object with message key
    const testUser = config.validUser.user1;    
    request(app)
      .post('/api/v1/users/register')
      .send(testUser)
      .expect(403)
      .end((error, response) => {
        if(error) return done(error);
        const bmessage = response.body.message;
        bmessage.should.equal(config.responseMessages.userExists, 'response should have proper error message');
      });
    done();
  });
});

//  testsuite
describe('Testing to login user', function()
{
  //  testcase
  it('Should handle a request to successfully login', function(done)
  {
    //Response body should have a key as user which will hold userName as a key and it will hold username value
    // status code = 200
    // response body will hold user.userName
    const testUser = config.validUser.user1;
    request(app)
      .post('/api/v1/users/login')
      .send(testUser)
      .expect(200)
      .end((error, response) => {
        if(error) return done(error);        
        const username = response.body.user.userName;
        username.should.equal(testUser.username, 'response should return proper userInfo');
      });    
    done();
  });

  //  testcase
  it('Should handle a request to login with wrong password', function(done)
  {
   //Response body should have a key as message which will hold value as 'Password is incorrect'
   // status code = 403
   // response body will hold an object with message key
   const testUser = config.invalidUser.userPassInvalid;
    request(app)
      .post('/api/v1/users/login')
      .send(testUser)
      .expect(403)
      .end((error, response) => {
        if(error) return done(error);
        const bmessage = response.body.message;
        bmessage.should.equal(config.responseMessages.incorrectPassword, 'response should return proper userInfo');
      });        
    done();
  });

  //  testcase
  it('Should handle a request to login with wrong username', function(done)
  {
    //Response body should have a key as message which will hold value as 'You are not registered user'
    // status code = 403
    // response body will hold an object with message key
    const testUser = config.invalidUser.userNameInvalid;
    request(app)
      .post('/api/v1/users/login')
      .send(testUser)
      .expect(403)
      .end((error, response) => {
        if(error) return done(error);
        const bmessage = response.body.message;
        bmessage.should.equal(config.responseMessages.incorrectUserName, 'response should return proper userInfo');
      });        
    done();
  });
});