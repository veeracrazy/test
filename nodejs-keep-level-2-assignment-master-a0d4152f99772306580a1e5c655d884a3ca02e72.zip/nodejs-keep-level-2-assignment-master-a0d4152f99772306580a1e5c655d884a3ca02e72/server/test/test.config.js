//  Test Configuration Object

const validUser = {
    user1: { username: 'admin@gmail.com', password: 'test' },    
    user2: { username: 'user2@gmail.com', password: 'test' }
};

const invalidUser = {
    userPassInvalid: { username: 'admin@gmail.com', password: 'test123' },
    userNameInvalid: { username: 'usernotfound', password: 'test123' },
};

const notes = {
  note1: { title: 'test', text: 'test', state: 'not-started' },
  note2: { title: 'test', text: 'test', state: 'not-started' }
}

const authPayload = {name: 'test'}

const responseMessages = {
    userExists: 'username is already exist',
    incorrectPassword: 'Password is incorrect',
    incorrectUserName: 'You are not registered user'
};

module.exports = {
    validUser,
    invalidUser,
    notes,
    authPayload,
    responseMessages
};

