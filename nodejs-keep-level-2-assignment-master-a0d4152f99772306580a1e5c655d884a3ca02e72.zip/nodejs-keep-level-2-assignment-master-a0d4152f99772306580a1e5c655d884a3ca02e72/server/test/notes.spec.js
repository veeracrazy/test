const should = require('chai').should();
const request = require('supertest');
const app = require('../app');
const config = require('./test.config');
const { authConfig } = require('../config/appConfig');
const modules = require('../modules');

const USER_ID_1 = '1';
const USER_ID_2 = '2';

let token1;
let token2;
let token3;

// remove all notes
before((done) => {
  modules.noteModel.remove({}, (err) => {
    if(err) return done(err);
    done();
  });
});

// Generate 3 tokens
before((done) => {  
  modules.signJWTToken(config.validUser.user1, authConfig.secret, '1h', (err, token) => {
      if(err) return done(err);
      token1 = token;
      done();
  });
});
before((done) => {
  modules.signJWTToken(config.validUser.user2, authConfig.secret, '1h', (err, token) => {
      if(err) return done(err);
      token2 = token;
      done();
  });
});
// Generate token for invalid user
before((done) => {
  modules.signJWTToken(config.invalidUser.userNameInvalid, authConfig.secret, '1h', (err, token) => {
      if(err) return done(err);
      token3 = token;
      done();
  });
});

//  testsuite
describe('Testing to add a note', function()
{
  //  testcase
  it('Should handle a request to add a new note for user 1 ', function(done)
  {
    // Should get added note of user 1 as a respone,  need to match added note text value
    // status = 201
    // response will be added note object
    const testNote = config.notes.note1;
    request(app)
      .post('/api/v1/notes/?userId=' + USER_ID_1)
      .set('Authorization', 'Bearer ' + token1)
      .send(testNote)
      .expect(201)
      .end((error, response) => {
        if(error) return done(error);        
        response.body.text.should.equal(testNote.text, 'response should return proper note text');
      });
    done();
  });

  //  testcase
  it('Should handle a request to add a new note for user 2', function(done)
  {
    // Should get added note of user 2 as a respone,  need to match added note text value
    // status = 201
    // response will be added note object
    const testNote = config.notes.note2;
    request(app)
      .post('/api/v1/notes/?userId=' + USER_ID_2)
      .set('Authorization', 'Bearer ' + token2)
      .send(testNote)
      .expect(201)
      .end((error, response) => {
        if(error) return done(error);
        response.body.text.should.equal(testNote.text, 'response should return proper note text');
      });
    done();
  });
});

//  testsuite
describe('Testing to get all notes', function()
{
  //  testcase
  it('Should handle a request to get all notes of a user 1', function(done)
  {
    // Should get all note as a array those are created by user 1 and Should match recently added note text value
    // status = 200
    // response will be a array or all notes those are added by user 1
    const testNote = config.notes.note1;    
    request(app)
      .get('/api/v1/notes/?userId=' + USER_ID_1)
      .set('Authorization', 'Bearer ' + token1)
      .expect(200)
      .end((error, response) => {
        if(error) return done(error);
        const notes = response.body;        
        const noteText = notes[notes.length - 1].text;
        noteText.should.equal(testNote.text, 'response should return proper note text');
      });
    done();
  });

  //  testcase
  it('Should handle a request to get all notes of a user 2', function(done)
  {
    // Should get all note as a array those are created by user 2 and Should match recently added note text value
    // status = 200
    // response will be a array or all notes those are added by user 2
    const testNote = config.notes.note2;    
    request(app)
      .get('/api/v1/notes/?userId=' + USER_ID_2)
      .set('Authorization', 'Bearer ' + token2)
      .expect(200)
      .end((error, response) => {
        if(error) return done(error);
        const notes = response.body;        
        const noteText = notes[notes.length - 1].text;
        noteText.should.equal(testNote.text, 'response should return proper note text');
      });
    done();

  });

  //  testcase
  it('Should handle a request to get notes of a user who has not created any note', function(done)
  {
    // should get blank array
    // status = 200
    // response will be an empty array       
    request(app)
      .get('/api/v1/notes/?userId=0')
      .set('Authorization', 'Bearer ' + token3)
      .expect(200)
      .end((error, response) => {
        if(error) return done(error);        
        response.body.length.should.equal(0, 'response should return proper note text');
      });
    done();
  });
});

//  testsuite
describe('Testing to update a note', function()
{
  //  testcase
  it('Should handle a request to update a note by note id', function(done)
  {
    // Should return updated note and match updated note text value'
    // status = 200
    // response will hold updated note as an object
    done();
  });
});

describe('Negative test scenarios', function() {
  it('Make a API request to a resource with invalid token, which requires authentication, should return forbidden status and error ', function(done) { 
    request(app)
      .get(`/api/v1/notes`)
      .set('Authorization', 'Bearer invalid-token')
      .expect(403)
      .end((error, response) => {
        if(error) return done(error);
        const message = response.text;
        message.should.equal('Invalid Token', 'Invalid token error message');
        done();
      });
  });

  it('Make a API request to a resource without any token, which requires authentication, should return forbidden status and error ', function(done) {
    request(app)
      .get(`/api/v1/notes`)
      .expect(403)
      .end((error, response) => {
        if(error) return done(error);
        const message = response.text;
        message.should.equal('Not Authorized', 'Not Authorized error message');
        done();
      });
  });
});
