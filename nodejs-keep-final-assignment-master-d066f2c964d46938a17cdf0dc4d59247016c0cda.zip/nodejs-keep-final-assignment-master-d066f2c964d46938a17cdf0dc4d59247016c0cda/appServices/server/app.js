let express = require('express');
let app = express();
const httpProxy = require('http-proxy-middleware');
const appConfig = require('./config').appConfig;
const cors = require('cors');
const middleware = require('./app.middleware');
const apiV1 = require('./api/v1');
const db = require('./db');


// create db connection
db.createDbConnection();
let dbConnection = db.getDbConnection();
dbConnection.on('error', db.onError);
dbConnection.once('open', db.onSuccess);

// express middleware
middleware.setMiddleware(app);

// api configuration
app.use('/api/v1/', apiV1);

/*
proxyNotificationService = httpProxy({ target: appConfig.NOTIFICATIONS_API_URL, changeOrigin: true });
app.use('/api/v1/notifications', proxyNotificationService);

proxySocket = httpProxy({ target: appConfig.NOTIFICATIONS_API_URL, changeOrigin: true, ws: true });
app.use('/', proxySocket);
*/

app.use((req, res) => {
	res.status(404).send({message: 'Resource not found..!'});
});

module.exports = app;