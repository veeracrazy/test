// write your application configration here

const appConfig = {
  PORT: process.env.PORT || 3000,  
  API_URL: process.env.API_URL || 'http://localhost:3000/',
  NOTIFICATIONS_API_URL: process.env.NOTIFICATIONS_API_URL || 'http://localhost:3003/'
};

const dbConfig = {
  mongoUrl: process.env.MONGO_URL || 'mongodb://localhost:27017/notes-app-dev'
};

const authConfig = {
  secret: 'some-secret-value',
  expiry: '10h'
};

const logConfig = {
  level: process.env.LOG_LEVEL || 'debug'
};

module.exports = {
  appConfig,
  dbConfig,
  authConfig,
  logConfig
}
